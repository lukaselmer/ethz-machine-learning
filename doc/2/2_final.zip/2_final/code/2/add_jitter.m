function [ x_train, y_train ] = add_jitter( x_train, y_train )
    %y_train = [y_train ; y_train];
    %r1 = rand(size(x_train)).*0.000001;
    %x_train = [x_train ; x_train + r1];
end

