import java.io.File;
import java.io.IOException;

import org.apache.mahout.cf.taste.model.DataModel;

public class Main {

	public static void main(String[] args) throws IOException {
		// InputData = new InputData("data/2/validation.csv");

		File file = new File("../../data/2/validation.csv");
		System.out.println(file.exists());

		DataModel data;

	}

}
