require_relative 'classifier'
c = Classifier.new
c.run