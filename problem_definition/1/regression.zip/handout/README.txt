Project 1 - Regression.pdf : Contains detailed task definition.
report.tex                 : Contains the LaTeX template for the task report.
report.pdf                 : If you are not using LaTeX, this is how your report should look like. 
training.csv               : Contains the training dataset.
validation.csv             : Contains the validation dataset.
testing.csv                : Contains the testing dataset.
